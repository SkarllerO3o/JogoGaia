 ////Codigos do Carro

//Carros

let yCarros = [40 , 150 ,95];
let xCarro = [600, 600, 600]
let velocidadeCarro = [2,3,5];



function mostraCarro(){
  for(let i = 0; i < imagemCarros.length; i++){
    image(imagemCarros[i], xCarro[i], yCarros[i], 50, 40);
    
  }
 
}

function movimentaCarro(){
  for(let i = 0; i < imagemCarros.length; i++){
    
    xCarro[i] -= velocidadeCarro[i]
   
}
  }
  

function voltaCarro(){
  
  for(let i = 0; i < imagemCarros.length; i++){
    
  if( passoutodaTela(xCarro[i])){
    xCarro[i] = 600
  
    }
  }
}

function passoutodaTela(xCarro){
  return xCarro < - 50;
  
}
 