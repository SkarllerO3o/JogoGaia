//Codigos do Ator


let yAtor = 366
let xAtor = 100
let velocidadeAtor = 2


function mostraAtor(){
  
   image(imagemAtor, xAtor , yAtor , 70, 70);
}

function movimentaAtor(){
  if (keyIsDown(87)){
    yAtor -= velocidadeAtor;
  }
  if (keyIsDown(83)){
    yAtor += velocidadeAtor;
  }
  if (keyIsDown(68)){
    xAtor += velocidadeAtor;
  }
  if (keyIsDown(65)){
    xAtor -= velocidadeAtor;
  }
}

function voltaAtor(){
  if (yAtor == yCarro[0] && xAtor == xCarro[0] ){
    yAtor = 366
  }
}