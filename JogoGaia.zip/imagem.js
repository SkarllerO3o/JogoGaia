// Imagens do Jogo

let imagemEstrada
let imagemCarro
let imagemCarro2
let imagemCarro3
let imagemAtor

function preload(){
  
  imagemEstrada = loadImage("Imagens/estrada.png");
  imagemAtor = loadImage("Imagens/gaia.png");
  imagemCarro2 = loadImage("Imagens/carro2.png");
  imagemCarro3 = loadImage("Imagens/carro3.png");
  imagemCarro = loadImage("Imagens/carro2.png");
  imagemCarros = [imagemCarro2,imagemCarro3,imagemCarro]
  
  
}
