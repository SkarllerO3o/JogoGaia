

function setup() {
  createCanvas(500, 400);
}

function draw() {
  background(imagemEstrada);
  mostraAtor();
  mostraCarro();
  movimentaCarro();
  movimentaAtor();
  voltaCarro();
  //voltaAtor()
}



function mostraCarro(){
  image(imagemCarro2, xCarro, 40, 50, 40);
}

function movimentaCarro(){
  xCarro -= velocidadeCarro
}
 
function movimentaAtor(){
  if (keyIsDown(87)){
    yAtor -= velocidadeAtor;
  }
  if (keyIsDown(83)){
    yAtor += velocidadeAtor;
  }
  if (keyIsDown(68)){
    xAtor += velocidadeAtor;
  }
  if (keyIsDown(65)){
    xAtor -= velocidadeAtor;
  }
}


  























